from app.logger import logger
import pika
from app.config import RABBITMQ_HOST, QUEUE_NAME, RABBITMQ_PASS, RABBITMQ_USER
import time

def connect_to_rabbitmq():
    """Establish a connection to RabbitMQ and return the channel."""
    while True:
        try:
            credentials = pika.PlainCredentials(RABBITMQ_USER, RABBITMQ_PASS)
            connection = pika.BlockingConnection(pika.ConnectionParameters(host=RABBITMQ_HOST, credentials=credentials))
            channel = connection.channel()
            arguments = {
                "x-max-length": 100,         # Maximum number of messages in the queue
                "x-message-ttl": 3600000,    # Time-to-live for messages (1 hour)
                "x-queue-mode": "lazy"       # Configure as lazy queue
            }
            channel.queue_declare(queue=QUEUE_NAME, durable=True, arguments=arguments)
            return channel, connection
        except Exception as e:
            logger.exception(f"RabbitMQ connection failed: {e}")
            time.sleep(10)  # Retry after 5 seconds
