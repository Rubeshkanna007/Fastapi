from fastapi import APIRouter, Depends, HTTPException
from app.utils.rabbitmq import connect_to_rabbitmq
import json
from app.config import QUEUE_NAME
import pika
from app.api_key import validate_api_key
from app.logger import logger

router = APIRouter()

@router.post("/publish/")
def publish_message(data: dict, api_key: str = Depends(validate_api_key)):
    channel, connection = None, None
    try:
        channel, connection = connect_to_rabbitmq()
        message = json.dumps(data)

        channel.basic_publish(
            exchange='',
            routing_key=QUEUE_NAME,
            body=message,
            properties=pika.BasicProperties(delivery_mode=2),  # Persistent message
        )
        logger.info(f"API request to publish data: {data}")
        return {"status": "success", "message": f"Message sent to queue '{QUEUE_NAME}'."}
    except Exception as e:
        logger.exception(f"An error occurred while publishing message: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to publish message: {str(e)}")
    finally:
        if connection:
            connection.close()
