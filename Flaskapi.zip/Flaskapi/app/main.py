from fastapi import Depends, FastAPI
from fastapi.middleware.cors import CORSMiddleware
import uvicorn
from app.routers import publisher
from app.api_key import validate_api_key

app = FastAPI()

# Include publisher routes
app.include_router(publisher.router)

# Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Adjust origins for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
def health_check(api_key: str = Depends(validate_api_key)):
    return {"status": "healthy"}

#code to execute in cmd to run this application without using main method
#uvicorn app.main:app --reload

# Run the app
# if __name__ == "__main__":
#     uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)

#To run using above main method
#python -m app.main
