import os

RABBITMQ_HOST = os.getenv("RABBITMQ_HOST", "dev.rabbitmq-mgmt.ind4.saint-gobain.com")
RABBITMQ_USER = os.getenv("RABBITMQ_USER", "admin")
RABBITMQ_PASS = os.getenv("RABBITMQ_PASS", "admin123")
QUEUE_NAME = os.getenv("QUEUE_NAME", "data_queue")
